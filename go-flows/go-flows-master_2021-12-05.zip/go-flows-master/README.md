go-flows
========

[![GoDoc](https://godoc.org/github.com/CN-TU/go-flows?status.svg)](https://godoc.org/github.com/CN-TU/go-flows)

This is a highy customizable general-purpose flow exporter. For more
information have a look at [godoc](https://godoc.org/github.com/CN-TU/go-flows).

This flow exporter implementation will be featured in an upcoming journal publication. As soon as it is published, we will replace this information with the citation. Please use this citation, if available.
