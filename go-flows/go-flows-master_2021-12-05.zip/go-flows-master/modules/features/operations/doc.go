// Package operations contains operations (features that use featureoutput, e.g., min).
package operations
