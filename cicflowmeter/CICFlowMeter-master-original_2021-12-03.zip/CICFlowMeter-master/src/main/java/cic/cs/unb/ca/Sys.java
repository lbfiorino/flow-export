package cic.cs.unb.ca;

public class Sys {
	public static final String FILE_SEP = System.getProperty("file.separator");
	public static final String LINE_SEP = System.lineSeparator();
}
