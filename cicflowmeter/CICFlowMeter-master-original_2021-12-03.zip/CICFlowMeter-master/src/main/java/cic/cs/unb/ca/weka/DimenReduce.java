package cic.cs.unb.ca.weka;

public interface DimenReduce {
	double[][] dimensionReduce(double[][] data);
}
