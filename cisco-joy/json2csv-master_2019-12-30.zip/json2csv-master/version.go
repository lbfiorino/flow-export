package main

const VERSION = "1.2.1"
