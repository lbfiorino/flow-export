#ifndef __MEM_PRIMITIVES_LIB__
#define __MEM_PRIMITIVES_LIB__

#endif // __MEM_PRIMITIVES_LIB__
