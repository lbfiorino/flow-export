#ifndef WIN_TYPES_DEF
#define WIN_TYPES_DEF

#include "stdint.h"

#define VERSION "4.5.0"

#define PCAP_NETMASK_UNKNOWN    0xffffffff

#define snprintf _snprintf

typedef unsigned char u_char;

#endif
